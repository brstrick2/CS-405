// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Changes made as part of the Module Four Activity by Ben Strickland

#include <iostream>
#include <exception>

//Create a custom exception subclass of the exception library.
struct CustomException : public std::exception 
{
    const char* what() const throw () 
    {
        return "Custom exception caught.";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    // Going to throw a std::invalid_argument exception to be caught by the calling do_custom_application_logic function.
    throw std::invalid_argument("Invalid argument exception.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    //Wrap the original function in a try-catch clause.
    try {
        std::cout << "Running Custom Application Logic." << std::endl;

        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    //Catch the invalid_argument exception thrown from the do_even_more_custom_application_logic function,
    // and inform the user by outputting the error to the console.
    catch (std::exception e) { 
        std::cout << e.what() << std::endl;
    }
        

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    //Simply throwing the custom exception to be caught in main.
    throw CustomException();
    std::cout << "Leaving Custom Application Logic." << std::endl;
    
    

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    //Check to see if the denominator is zero. If so, throw a runtime error exception
    // which will be caught by the calling function do_division.
    if (den == 0) 
    {
        throw std::runtime_error("Divide by zero not allowed.");
    }
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    //Wrap the original function in a try-catch clause.
    try
    {
        float numerator = 10.0f;
        float denominator = 0;
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    //Catch the runtime error thrown by the divide function and put its error information on the console.
    catch (std::runtime_error re)
    {
        std::cout << re.what() << std::endl;
    }
}

int main()
{
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        // TODO: Create exception handlers that catch (in this order):
        //  your custom exception
        //  std::exception
        //  uncaught exception 
        //  that wraps the whole main function, and displays a message to the console.
        do_division();
        do_custom_application_logic();
    }
    //Catch the custom exception thrown at the end of the do_custom_application_logic function.
    catch(CustomException ce){
        std::cout << ce.what() << std::endl;
    }
    //Catch any generic std::exceptions.
    catch (std::exception se) {
        std::cout << se.what() << std::endl;
    }
    //Catch all exceptions. This handler will catch any other exception thrown that was not caught previously.
    catch (...) {
        std::cout << "Uncaught exception was caught." << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu